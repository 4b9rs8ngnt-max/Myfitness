# Myfitness — free starter web app

This is a mobile-friendly starter PWA for iPhone. It includes local workout, food and progress logging.

## Important limitations
- Entries are stored only in the browser on the device. Clearing Safari website data can erase them.
- There are no real member accounts, shared cloud database, photo uploads, owner access, community feed, AI coaching, barcode lookup, or payments yet.
- Do not use this starter for sensitive member records. A production version needs secure authentication, access rules, consent/disclosure, backups and privacy controls.
- The 14-day trial and £2.99/month plan are display-only; no subscription is charged.

## Publish free with GitHub Pages
1. Create/sign in to a GitHub account at https://github.com
2. Create a new public repository named `myfitness`.
3. Upload all four files from this folder (`index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`) to the repository root.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to provide the site URL.

## Add to iPhone Home Screen
1. Open the published URL in Safari (not an in-app browser).
2. Tap Share (square with arrow).
3. Choose **Add to Home Screen**, then tap **Add**.
